
A basic android app to add and display student timetable.
This app uses firebase authentication system and firebase database as backend.  
All the timetable data is stored and managed online.  
The purpose of this app is to keep our timetable arranged and manage it easily wherever we are.
This app also demonstrates the working concepts of firebase database.
 

