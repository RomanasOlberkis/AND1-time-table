package com.appsforfun.project.TimeTb.models;

public class TimetableModel {
    public int importance;
    public String taskName, contact, reasoning, location, key, time;
    public TimetableModel(){

    }
    public TimetableModel(int importance, String taskName, String contact, String reasoning, String location, String key, String time) {
        this.importance = importance;
        this.taskName = taskName;
        this.contact = contact;
        this.reasoning = reasoning;
        this.location = location;
        this.key = key;
        this.time = time;
    }
}
