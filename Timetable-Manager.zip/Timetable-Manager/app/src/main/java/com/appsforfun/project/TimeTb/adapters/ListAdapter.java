package com.appsforfun.project.TimeTb.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.appsforfun.project.TimeTb.R;
import com.appsforfun.project.TimeTb.models.TimetableModel;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ListViewHolder>{

    private List<TimetableModel> list;

    public ListAdapter(List<TimetableModel> list){
        this.list = list;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ListViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_view, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder listViewHolder, int i) {
        TimetableModel timetable = list.get(i);
        listViewHolder.taskName.setText(timetable.taskName);
        listViewHolder.importance.setText(timetable.importance + "");
        listViewHolder.contact.setText(timetable.contact);
        listViewHolder.location.setText(timetable.location);
        listViewHolder.reasoning.setText(timetable.reasoning);
        listViewHolder.time.setText(timetable.time);
        listViewHolder.itemView.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
            @Override
            public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
                menu.add(listViewHolder.getAdapterPosition(), 0, 0, "Delete");
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ListViewHolder extends RecyclerView.ViewHolder{

        TextView taskName, importance, contact, location, reasoning, time;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            taskName = itemView.findViewById(R.id.tv_task_name);
            importance = itemView.findViewById(R.id.tv_task_importance);
            contact = itemView.findViewById(R.id.tv_contact);
            location = itemView.findViewById(R.id.tv_location);
            reasoning = itemView.findViewById(R.id.tv_reasoning);
            time = itemView.findViewById(R.id.tv_time);
        }
    }
}
